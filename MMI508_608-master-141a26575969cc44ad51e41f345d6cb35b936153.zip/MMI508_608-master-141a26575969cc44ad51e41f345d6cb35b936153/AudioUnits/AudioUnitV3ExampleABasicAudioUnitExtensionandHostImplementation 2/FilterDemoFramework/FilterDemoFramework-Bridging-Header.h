//
//  FilterDemoFramework-Bridging-Header.h
//  AudioUnitV3Example
//
//  Created by ALICIA JACKSON on 3/3/16.
//
//

#ifndef FilterDemoFramework_Bridging_Header_h
#define FilterDemoFramework_Bridging_Header_h

//#import "FilterDemoViewController.h"


#endif /* FilterDemoFramework_Bridging_Header_h */

