//
//  main.m
//  classexample
//
//  Created by Christopher Bennett on 1/30/18.
//  Copyright © 2018 Christopher Bennett. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
