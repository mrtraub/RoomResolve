//
//  App3.h
//  AudioPlayer
//
//  Created by ALICIA JACKSON on 2/25/16.
//  Copyright © 2016 University of Miami. All rights reserved.
//


/* DUE TUESDAY 3/23
 
 - (25) Add metered AV Input Node
 - (25) Add an AV Audio Unit Effect of your choice - break out all effect parameters to user!
 - (25) Add real-time FFT magnitude plot of microphone
 - (25) Add Audio Session to set appropriate category, sample rate, buffer size, etc.
 
 Other ideas (bonus points):
 * Spectrogram of microphone audio
 * (5) Add a pre/post fx switch for fft
 
 
 
 */