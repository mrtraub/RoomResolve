//
//  main.m
//  EQCalculator
//
//  Created by willpirkle on 12/22/10.
//  Copyright 2010 University of Miami. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EQCalculatorAppDelegate.h"

int main(int argc, char *argv[]) {
    
    int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([EQCalculatorAppDelegate class]));

    return retVal;
}
