//
//  AppDelegate.h
//  quiz
//
//  Created by ALICIA JACKSON on 1/5/16.
//  Copyright © 2016 oygo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuizViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) QuizViewController *quizVC;


@end

