//
//  myModel.h
//  quiz
//
//  Created by ALICIA JACKSON on 1/6/16.
//  Copyright © 2016 oygo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface myModel : NSObject

@property float myNumber;

-(float) roundFloat:(float)fVal;

@end
