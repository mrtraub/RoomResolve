//
//  Banana.m
//  ProtocolDemo_Simple
//
//  Created by Dave Viggiano on 2/3/16.
//  Copyright © 2016 UM FORE Center. All rights reserved.
//

#import "Banana.h"

@implementation Banana

//This is the specifics for a Banana

-(NSString *) getFlavor
{
    return @"Plantain-flavored";
}

-(int) getCalories
{
    return 200;
}

@end
