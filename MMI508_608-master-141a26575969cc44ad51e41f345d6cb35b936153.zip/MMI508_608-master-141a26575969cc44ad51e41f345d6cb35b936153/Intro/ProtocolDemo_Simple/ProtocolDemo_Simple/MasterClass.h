//
//  MasterClass.h
//  ProtocolDemo_Simple
//
//  Created by Dave Viggiano on 2/3/16.
//  Copyright © 2016 UM FORE Center. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProtocolDefinitions.h"
#import "Apple.h"
#import "Banana.h"

@interface MasterClass : NSObject

-(void) runDemo;

@end
