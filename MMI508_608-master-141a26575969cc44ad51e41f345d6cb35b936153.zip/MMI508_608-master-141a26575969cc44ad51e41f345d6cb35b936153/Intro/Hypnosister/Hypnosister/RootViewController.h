//
//  RootViewController.h
//  Hypnosister
//
//  Created by ALICIA JACKSON on 1/20/16.
//  Copyright © 2016 UM. All rights reserved.
//

// 1) create a new Class RootViewController (subclass UIViewController)
// 2a) go to AppDelegate.h and add the RootViewController as, well, the root view controller


#import <UIKit/UIKit.h>
#import "BNRHypnosisView.h"




@interface RootViewController : UIViewController

@end
