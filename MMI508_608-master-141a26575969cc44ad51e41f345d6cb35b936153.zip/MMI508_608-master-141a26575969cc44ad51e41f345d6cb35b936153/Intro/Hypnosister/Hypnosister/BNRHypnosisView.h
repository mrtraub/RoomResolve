//
//  BNRHypnosisView.h
//  Hypnosister
//
//  Created by ALICIA JACKSON on 1/21/16.
//  Copyright © 2016 UM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRHypnosisView : UIView


// 20) add a new  property to hold the circle color

@property (strong, nonatomic) UIColor *circleColor;
@property CGRect myRect;

@end
