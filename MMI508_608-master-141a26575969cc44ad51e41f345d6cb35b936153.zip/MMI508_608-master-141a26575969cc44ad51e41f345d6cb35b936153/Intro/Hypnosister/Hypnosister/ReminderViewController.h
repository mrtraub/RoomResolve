//
//  ReminderViewController.h
//  Hypnosister
//
//  Created by ALICIA JACKSON on 2/1/16.
//  Copyright © 2016 UM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReminderViewController : UIViewController

@end
