//
//  main.m
//  classExample
//
//  Created by THE ONE AND ONLY DR. BENNETT on 1/1/18.
//  Copyright © 2018 UM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
