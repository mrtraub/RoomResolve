//
//  AppDelegate.h
//  classExample
//
//  Created by THE ONE AND ONLY DR. BENNETT on 1/1/18.
//  Copyright © 2018 UM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

{
    // could put variables here
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *myVC;


@end

