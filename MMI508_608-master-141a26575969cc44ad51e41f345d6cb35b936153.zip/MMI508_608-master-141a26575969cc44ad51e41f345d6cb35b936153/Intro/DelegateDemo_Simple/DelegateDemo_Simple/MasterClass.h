//
//  MasterClass.h
//  DelegateDemo_Simple
//
//  Created by Dave Viggiano on 2/3/16.
//  Copyright © 2016 UM FORE Center. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Customer.h"
#import "GasStationAttendant.h"

@interface MasterClass : NSObject

-(void) runTheDemo;

@end
