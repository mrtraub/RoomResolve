//
//  AppDelegate.h
//  FunWithProperties
//
//  Created by ALICIA JACKSON on 1/28/16.
//  Copyright © 2016 UM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;


@end

