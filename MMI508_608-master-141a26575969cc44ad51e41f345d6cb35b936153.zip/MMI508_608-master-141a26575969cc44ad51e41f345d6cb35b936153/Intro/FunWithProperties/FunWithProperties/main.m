//
//  main.m
//  FunWithProperties
//
//  Created by ALICIA JACKSON on 1/28/16.
//  Copyright © 2016 UM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
